/**
 * Abrir o XML da Torre e da Wiki
 * 
 */
var XMLHttp = new XMLHttpRequest();
XMLHttp.open("GET", "../static/database/tower_plant.xml", false);
XMLHttp.send();
var xmlTowerFile = XMLHttp.responseXML;  


/**
 * WIKI info XML
 */
var XMLHttp = new XMLHttpRequest();
XMLHttp.open("GET", "../static/database/wiki.xml", false);
XMLHttp.send();
var xmlWiki = XMLHttp.responseXML;  



/**
 * Get each slot 
 */
const plantElements = [
    document.getElementById('plant-l1-img'),
    document.getElementById('plant-l2-img'),
    document.getElementById('plant-l3-img'),
    document.getElementById('plant-l4-img'),
    document.getElementById('plant-r1-img'),
    document.getElementById('plant-r2-img'),
    document.getElementById('plant-r3-img'),
    document.getElementById('plant-r4-img')
];

var plantNameInput = document.getElementById('plant-name');
var plantAgeInput = document.getElementById('plant-age');
var plantCycleInput = document.getElementById('plant-cycle');
var plantAirtempMinInput = document.getElementById('plant-airtemp-min');
var plantAirtempMaxInput = document.getElementById('plant-airtemp-max');
var plantHumidMinInput = document.getElementById('plant-humid-min');
var plantHumidMaxInput = document.getElementById('plant-humid-max');
var plantLightMinInput = document.getElementById('plant-light-min');
var plantLightMaxInput = document.getElementById('plant-light-max');
var plantPhMinInput = document.getElementById('plant-ph-min');
var plantPhMaxInput = document.getElementById('plant-ph-max');
var plantEcMinInput = document.getElementById('plant-ec-min');
var plantEcMaxInput = document.getElementById('plant-ec-max');


/**
 * Adicionar Listener a cada Slot
 */
plantElements.forEach((plantElement, index) => {
    plantElement.addEventListener("click", (event) => {
        var slotID = "E";
        if(index<4){
            slotID = `L${index + 1}`;
        }else{
            var index_aux = index-4;
            slotID = `R${index_aux + 1}`;
        }
        const slot = xmlTowerFile.querySelector(`slot[id="${slotID}"]`);
        const plantID = slot.querySelector('plant-id').textContent;
        if(plantID != ""){
            const wikiPlant = xmlWiki.querySelector(`plant[id="${plantID}"]`);
            updatePlantFields(wikiPlant, slot);
        }
    });
});

/**
 * Função para atualizar os campos de informações da planta com base nos dados da WIKI e da Torre.
 *
 * @param {XML} wikiPlant - Os dados da planta da WIKI.
 * @param {XML} slot - Os dados da planta da Torre.
 */
function updatePlantFields(wikiPlant, slot) {
    if (wikiPlant != null) {
        plantNameInput.value = wikiPlant?.querySelector('name')?.textContent || '';
        plantAgeInput.value = slot?.querySelector('plant-age')?.textContent || '';

        var inserted_date = slot?.querySelector('plant-inserted-date')?.textContent || '';
        var plantCycleInput = document.getElementById('plant-cycle');
        plantCycleInput.value = calculateDaysOfLife(inserted_date);
        

        plantAirtempMinInput.value = wikiPlant?.querySelector('tempMin')?.textContent || '';
        plantAirtempMaxInput.value = wikiPlant?.querySelector('tempMax')?.textContent || '';
        plantHumidMinInput.value = wikiPlant?.querySelector('humidMin')?.textContent || '';
        plantHumidMaxInput.value = wikiPlant?.querySelector('humidMax')?.textContent || '';
        plantLightMinInput.value = wikiPlant?.querySelector('luzMin')?.textContent || '';
        plantLightMaxInput.value = wikiPlant?.querySelector('luzMax')?.textContent || '';
        plantPhMinInput.value = wikiPlant?.querySelector('phMin')?.textContent || '';
        plantPhMaxInput.value = wikiPlant?.querySelector('phMax')?.textContent || '';
        plantEcMinInput.value = wikiPlant?.querySelector('ecMin')?.textContent || '';
        plantEcMaxInput.value = wikiPlant?.querySelector('ecMax')?.textContent || '';    
    }
}

/**
 * Função para calcular a idade da planta em dias com base na data de inserção.
 *
 * @param {string} insertedDate - A data de inserção da planta.
 * @returns {string} - A idade da planta em dias.
 */
function calculateDaysOfLife(insertedDate) {
    const insertedDateObj = new Date(insertedDate);
    const currentDateObj = new Date();
    
    const timeDifference = currentDateObj - insertedDateObj;
    const daysDifference = Math.floor(timeDifference / (1000 * 60 * 60 * 24));
    if (isNaN(daysDifference)) {
        return "Menos de um Dia";
    } else if (daysDifference === 0) {
        return "Menos de um Dia";
    }

    return daysDifference;
}


/**
 * Code about the selected slot
 */

//Variable of a selected slot
var selectedSlotId;

var checkPlantSection1 = document.getElementById('checkPlantSection1');
var checkPlantSection2 = document.getElementById('checkPlantSection2');
var addPlantSection    = document.getElementById('addPlantSection');

var addButton  = document.getElementById('addPlantButton');
var remButton  = document.getElementById('removePlantButton');

/**
 * Função para selecionar uma planta e exibir informações com base no slot selecionado.
 *
 * @param {string} plantId - O ID do slot da planta selecionada.
 */
function selectPlant(plantId) {
    //Make the adaptation of a local variable to be global 
    selectedSlotId = plantId;

    //Remove previous selected plants
    const allPlants = document.querySelectorAll('.plant-image');
    allPlants.forEach((plant) => 
        plant.classList.remove('plant-selected')
    );
    
    const selectedPlant = document.getElementById(plantId);
    selectedPlant.querySelector('.plant-image').classList.add('plant-selected');

    var imgElement = selectedPlant.querySelectorAll('.plant-image')[0];
    hiddenH3.value = selectedSlotId;
    if (imgElement.src.endsWith("blank.png")){
        // Empty Slot
        checkPlantSection1.style.display = 'none';
        checkPlantSection2.style.display = 'none';
        remButton.style.visibility = 'hidden';
        addButton.style.visibility = 'visible';
        addPlantSection.style.display = 'block';
        document.querySelector('#addPlantSection').scrollIntoView({
            behavior: 'smooth'
        });   
    }
    else{
        addPlantSection.style.display = 'none'; 
        checkPlantSection1.style.display = 'block'; 
        checkPlantSection2.style.display = 'block'; 
        remButton.style.visibility = 'visible';
        addButton.style.visibility = 'hidden';
        document.querySelector('#checkPlantSection1').scrollIntoView({
            behavior: 'smooth'
        });
    }
  }