/*
* Variáveis
*/
const searchBtn = document.querySelector("#search-btn");
const searchBar = document.querySelector("#search-bar");

/**
 * Adicionar um Listener ao botão de "Procura" para executar a chamada 
 * a API
 */
searchBtn.addEventListener("click", () => {
  const location = searchBar.value;
  getWeatherData(location)
    .then(weatherData => {
      updateUI(weatherData);
    })
    .catch(error => {
      console.log(error);
    });
});

/**
 * Perante a localização inserida na barra de procura
 * realiza uma chamada à API e obtém os dados dessa localização
 * em formato JSON
 * @param {*} location 
 * @returns um dicionário correspondente aos dados principais do Tempo {temperatura, condição, local}
 */
function getWeatherData(location) {
    const apiKey = "84a8971fcc504670ff9d418df9f139b0";
    const language = "pt";
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${location}&units=metric&appid=${apiKey}&lang=${language}`;
    return fetch(url)
      .then(response => response.json())
      .then(data => {
        const weatherData = {
          temperature: data.main.temp,
          condition: data.weather[0].description,
          location: data.name,
          country: data.sys.country
        };
        return weatherData;
    });
}
/**
 * Ao receber o dicionário da função getWeatherData, 
 * atualiza os elementos HTML com os valores correspondentes
 * @param {*} weatherData 
 */
function updateUI(weatherData) {
    const temperature = document.querySelector("#temperature");
    const condition = document.querySelector("#condition");
    const local = document.querySelector("#local");

    condition.textContent = weatherData.condition.charAt(0).toUpperCase() + weatherData.condition.slice(1);
    local.textContent = `${weatherData.location}, ${weatherData.country}`;
    temperature.textContent = `${weatherData.temperature}°C`;
}

/**
 * Localização atual
 */
var local_temp = document.getElementById("#temperature");
var local_local = document.getElementById("#local");
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else {
        local_temp.textContent = "Não foi possível obter a localização";
    }
}

// Função para mostrar dados de previsão do tempo com base nas coordenadas de localização fornecidas
function showPosition(position) {
    getWeatherDataLatLong(position.coords.latitude, position.coords.longitude)
        .then(weatherData => {
            const temperature = document.querySelector("#temperature");
            const condition = document.querySelector("#condition");
            const local = document.querySelector("#local");
        
            condition.textContent = weatherData.condition.charAt(0).toUpperCase() + weatherData.condition.slice(1);
            local.textContent = `${weatherData.location}, ${weatherData.country}`;
            temperature.textContent = `${weatherData.temperature}°C`;
    })
        .catch(error => {
        console.log(error);
    });
}
  
/**
 * Perante a localização inserida na barra de procura
 * realiza uma chamada à API e obtém os dados dessa localização
 * em formato JSON
 * @param {*} location 
 * @returns um dicionário correspondente aos dados principais do Tempo {temperatura, condição, local}
 */
function getWeatherDataLatLong(lat, long) {
    const apiKey = "84a8971fcc504670ff9d418df9f139b0";
    const language = "pt";
    const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${long}&units=metric&appid=${apiKey}&lang=${language}`;
    return fetch(url)
    .then(response => response.json())
    .then(data => {
        const weatherData = {
        temperature: data.main.temp,
        condition: data.weather[0].description,
        location: data.name,
        country: data.sys.country
        };
        return weatherData;
    });
}