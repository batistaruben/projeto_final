const fileInput = document.getElementById('upload-image');
const plantImage = document.getElementById('plant-image');

const currentImageSrc = plantImage.src;

// Adicionar um listener para o evento 'change' do input de ficheiro
fileInput.addEventListener('change', function () {
    const selectedFile = fileInput.files[0];

    if (selectedFile) {
        const reader = new FileReader();

        reader.onload = function (e) {
            plantImage.src = e.target.result;
        };
        reader.readAsDataURL(selectedFile);
    }
});

// Adicionar um listener para o evento 'click' do input de arquivo
fileInput.addEventListener('click', function () {
    if (!fileInput.value) {
        plantImage.src = currentImageSrc;
    }
});

// Inserir a imagem carregada no <form> para enviá-la
document.getElementById('upload-image').addEventListener('change', function(event) {
    const fileInput = event.target;
    const file = fileInput.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function() {
            const imageData = reader.result.split(',')[1];
            document.getElementById('image-base64').value = imageData;
        };
        reader.readAsDataURL(file);
    } else {
        document.getElementById('image-base64').value = ''; // Clear the image base64 data
    }
});

// Função para substituir vírgulas por pontos em campos de entrada numérica
document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("myForm");
    form.addEventListener("submit", function(event) {
        const inputFields = form.querySelectorAll('input[type="number"]');		
        inputFields.forEach(input => {
            if (input.value.includes(",")) {
                input.value = input.value.replace(",", ".");
            }
        });
    });
});

