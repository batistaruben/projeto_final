const plantCicle = document.getElementById('plant-id');
const plantTitle = document.getElementById('plant-name-title');
const plantImg = document.getElementById('plant-image');
const plantDesc = document.getElementById('plant-desc');
var plantDictionary = getPlantNamesFromXML(); // Dic {id: name}

// Função para obter nomes de plantas do ficheiro XML
function getPlantNamesFromXML() {
    var plantDic = {}
    const XMLHttp = new XMLHttpRequest();
    XMLHttp.open("GET", "static/database/wiki.xml", false);
    XMLHttp.send();

    if (XMLHttp.readyState === 4 && XMLHttp.status === 200) {
        const xmlWiki = XMLHttp.responseXML;
        const plantElements = xmlWiki.getElementsByTagName('plant');

        for (let i = 0; i < plantElements.length; i++) {
            const plantId = plantElements[i].getAttribute('id');
            const plantName = plantElements[i].getElementsByTagName('name')[0].textContent.trim();
            plantDic[plantId] = plantName;
        }
        console.log(plantDic);
    } else {
        console.error("Error fetching or parsing XML:", XMLHttp.statusText);
    }
    return plantDic;
}

//Código que executa após o load completo da página
document.addEventListener('DOMContentLoaded', function() {

    const searchInput = document.getElementById('searchInput');
    const dropdownContent = document.getElementById('dropdownContent');

    /**
     * Fazer a procura de valores da planta
     */
    searchInput.addEventListener('input', function() {
        const searchTerm = searchInput.value.toLowerCase();
        showDropdownOptions(searchTerm);
    });

    function showDropdownOptions(searchTerm) {
        dropdownContent.innerHTML = '';

        for (const id in plantDictionary) {
            const name = plantDictionary[id];
            if (name.toLowerCase().includes(searchTerm)) {
            const option = document.createElement('a');
            option.textContent = name;
            option.setAttribute('data-id', id);
            option.addEventListener('click', function() {
                searchInput.value = name;
                dropdownContent.style.display = 'none';
            });
            dropdownContent.appendChild(option);
            }
        }
        if (dropdownContent.children.length > 0) {
            dropdownContent.style.display = 'block';
        } else {
            dropdownContent.style.display = 'none';
        }
    }

    /**
    * Controlar o visual do drop down caso seja clicked
    */
    document.addEventListener('click', function(event) {
        if (!dropdownContent.contains(event.target)) {
            dropdownContent.style.display = 'none';
        }
    });    
});

// Função para atualizar a página de informações da planta com base no ID da planta
function updatePlantPage(id){

    const XMLHttp = new XMLHttpRequest();
    XMLHttp.open("GET", "static/database/wiki.xml", false);
    XMLHttp.send();

    if (XMLHttp.readyState === 4 && XMLHttp.status === 200) {
        const xmlWiki = XMLHttp.responseXML;
        const plantElements = xmlWiki.getElementsByTagName('plant');

        for (let i = 0; i < plantElements.length; i++) {
            const plantId = plantElements[i].getAttribute('id');
            if(plantId === id){
                buttonToEdit(id);
                
                const choosenPlant = plantElements[i];
                hiddenH4.value = plantId;

                plantCicle.innerText = "";//"A planta tem "+choosenPlant.getElementsByTagName('ciclo')[0].textContent.trim()+" ciclos";
                plantTitle.innerText = choosenPlant.getElementsByTagName('name')[0].textContent.trim();
                plantImg.src = "static/database/plant_images/"+plantId+".jpeg";
                plantDesc.innerText = choosenPlant.getElementsByTagName('description')[0].textContent;

                // Clear previous rows from the table
                const table = document.getElementById('table-params');
                while (table.children.length > 1) {
                    table.removeChild(table.children[1]);
                }   
                
                fillParamsTable(choosenPlant);
                populatePhaseTable(choosenPlant);
            }
        }
    }
}

// Função para preencher a tabela de fases da planta
function populatePhaseTable(choosenPlant) {
    // Associate the phase name to xml tag
    const phases = [
        { name: 'Germinação', tag: 'germination' },
        { name: 'Vegetativo', tag: 'vegetative' },
        { name: 'Floração', tag: 'floration' },
        { name: 'Fruto', tag: 'fruiting' }
    ];

    const table = document.getElementById('table-phase');

    while (table.children.length > 1) { // Remove all rows except the first one
        table.removeChild(table.children[1]);
    }

    const nameRow = document.createElement('tr');
    phases.forEach(phase => {
        const phaseValue = choosenPlant.getElementsByTagName(phase.tag)[0]?.textContent.trim();

        // Check if the phase has a non-empty value
        if (phaseValue) {
            const phaseNameCell = document.createElement('th');
            phaseNameCell.style.textAlign = 'center';
            phaseNameCell.style.padding = '8px';
            phaseNameCell.style.border = '1px solid #000';
            phaseNameCell.style.backgroundColor = '#f2f2f2';
            phaseNameCell.innerText = phase.name;

            nameRow.appendChild(phaseNameCell);
        }
    });

    table.appendChild(nameRow);

    const valueRow = document.createElement('tr');
    phases.forEach(phase => {
        const phaseValue = choosenPlant.getElementsByTagName(phase.tag)[0]?.textContent.trim();

        // Check if the phase has a non-empty value
        if (phaseValue) {
            const phaseValueCell = document.createElement('td');
            phaseValueCell.style.textAlign = 'center';
            phaseValueCell.style.padding = '8px';
            phaseValueCell.style.border = '1px solid #000';
            phaseValueCell.innerText = phaseValue;

            valueRow.appendChild(phaseValueCell);
        }
    });

    table.appendChild(valueRow);
}

// Função para obter os valores da tabela de parâmetros
function getTableValues(choosenPlant){
    const tempMin = choosenPlant.getElementsByTagName('tempMin')[0].textContent.trim();
    const tempMax = choosenPlant.getElementsByTagName('tempMax')[0].textContent.trim();
    const luzMin = choosenPlant.getElementsByTagName('lightMin')[0].textContent.trim();
    const luzMax = choosenPlant.getElementsByTagName('lightMax')[0].textContent.trim();
    const humidMin = choosenPlant.getElementsByTagName('humidMin')[0].textContent.trim();
    const humidMax = choosenPlant.getElementsByTagName('humidMax')[0].textContent.trim();
    const phMin = choosenPlant.getElementsByTagName('phMin')[0].textContent.trim();
    const phMax = choosenPlant.getElementsByTagName('phMax')[0].textContent.trim();
    const ecMin = choosenPlant.getElementsByTagName('ecMin')[0].textContent.trim();
    const ecMax = choosenPlant.getElementsByTagName('ecMax')[0].textContent.trim();
    
    plantData = [
        tempMin,
        tempMax,
        luzMin,
        luzMax,
        humidMin,
        humidMax,
        phMin,
        phMax,
        ecMin,
        ecMax,
    ];

    return plantData;
}

// Função para criar uma linha na tabela
function createTableRow(header, data) {
    const row = document.createElement('tr');
    const headerCell = document.createElement('td');
    headerCell.classList.add('th-param');
    headerCell.textContent = header;
    row.appendChild(headerCell);
  
    for (const value of data) {
        const dataCell = document.createElement('td');
        dataCell.classList.add('td-param-center');
        dataCell.textContent = value;
        row.appendChild(dataCell);
    }
  
    return row;
}

// Função para preencher a tabela de parâmetros da planta
function fillParamsTable(choosenPlant){
    var data = getTableValues(choosenPlant);
    const table = document.getElementById('table-params');
    const parameters = [
        "Temperatura (ºC)", "Luz (Horas Diárias)", "Humidade (%)", "pH", "EC (mS/cm)"
    ];
    
    for (let i = 0; i < parameters.length; i++) {
        const paramRow = createTableRow(parameters[i], data.slice(i * 2, i * 2 + 2));
        table.appendChild(paramRow);
    }
}

// Inicialmente, atualiza a página com base no primeiro ID do dicionário de plantas
updatePlantPage(Object.keys(plantDictionary)[0]);

// Função para pesquisar e atualizar a página com base no nome da planta
function search() {
    const searchedPlant = document.getElementById('searchInput').value;
    console.log(searchedPlant)
    for (const key in plantDictionary) {
        if (plantDictionary[key] === searchedPlant) {
            return updatePlantPage(key);;
        }
    } 
}

// Função para atualizar o botão de edição com base no ID da planta selecionada
function buttonToEdit(id) {
    const editButton = document.getElementById('editButton');
    const editUrl = "hydrowiki_edit/plant_id="+id;
    editButton.href = editUrl;
}