// Função para carregar dados XML e exibir informações de plantas aleatórias
function getRandomPlants(){
    // Load the XML data
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var xmlDoc = xhttp.responseXML;
            populateRandomPlants(xmlDoc);
        }
    };
    xhttp.open("GET", "static/database/wiki.xml", true);
    xhttp.send();
}

// Função para mostrar informações de plantas aleatórias com base no XML fornecido
function populateRandomPlants(xmlDoc) {
    var plants = xmlDoc.getElementsByTagName("plant");

    var randomIndices = [];
    while (randomIndices.length < 4) {
        var randomIndex = Math.floor(Math.random() * plants.length);
        if (!randomIndices.includes(randomIndex)) {
            randomIndices.push(randomIndex);
        }
    }

    for (var i = 0; i < randomIndices.length; i++) {
        var plant = plants[randomIndices[i]];
        var plantId = plant.getAttribute("id");
        var plantName = plant.getElementsByTagName("name")[0].textContent;

        document.getElementById("plant" + (i + 1) + "Name").textContent = plantName;
        document.getElementById("plant" + (i + 1) + "Image").src = "static/database/plant_images/" + plantId + ".jpeg";
    }
}