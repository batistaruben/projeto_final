/**
 * Função para criar um gráfico com base em um parâmetro e data específicos.
 *
 * @param {string} parameter - O parâmetro para o qual o gráfico será criado.
 * @param {string} date - A data para a qual os dados do gráfico serão obtidos.
 */
function createChart(parameter, date) {
    $.ajax({
        url: '/data', // Update the URL endpoint as needed
        method: 'GET',
        dataType: 'json',
        data: {
            parameter: parameter, // Use camelCase parameter name
            date: date // 'yyyy-mm-dd' format
        },
        success: function (data) {
            if (data.length === 0) {
                console.log(`No ${parameter} data available for ${date}`);
                return;
            }

            // Convert Unix timestamps to "hour:min:sec" format
            data.forEach(function (point) {
                point[0] = new Date(point[0] * 1000).toLocaleTimeString('en-US', { hour12: false });
            });

            // Create a chart for water_temperature
            Highcharts.chart(`${parameter}Chart`, {
                chart: {
                    type: 'line'
                },
                title: {
                    text: `${parameter.charAt(0).toUpperCase() + parameter.slice(1)} Data` // Capitalize parameter name
                },
                xAxis: {
                    title: {
                        text: 'Time'
                    },
                    labels: {
                        format: '{value}' // Display the converted timestamp
                    }
                },
                yAxis: {
                    title: {
                        text: `${parameter.charAt(0).toUpperCase() + parameter.slice(1)} Value` // Capitalize parameter name
                    }
                },
                series: [{
                    name: parameter,
                    data: data,
                    color: 'green' // Choose a color for the line
                }]
            });
        },
        error: function (error) {
            console.error('Error fetching water_temperature data:', error);
        }
    });
}

/**
 * Função para criar um gráfico de pH com base na data especificada.
 *
 * @param {string} date - A data para a qual os dados do gráfico de pH serão obtidos.
 */
function createPHChart(date) {
    // Make an AJAX request to fetch pH data for the given date
    $.ajax({
        url: '/data',
        method: 'GET',
        dataType: 'json',
        data: {
            parameter: 'ph', 
            date: date // 'yyyy-mm-dd' format
        },
        success: function (data) {
            if (data.length === 0) {
                console.log(`No pH data available for ${date}`);
                return;
            }

            var pHData = data.map(function (point) {
                return {
                    x: point[0] * 1000, // Convert Unix timestamp to milliseconds
                    y: point[1],
                    time: new Date(point[0] * 1000).toLocaleTimeString('en-US', { hour12: false }) // Convert to time format
                };
            });

            Highcharts.chart('phChart', {
                chart: {
                    type: 'column' // Use column chart for pH
                },
                title: {
                    text: 'pH Data'
                },
                xAxis: {
                    type: 'datetime', // Specify datetime for the x-axis
                    title: {
                        text: 'Time'
                    }
                },
                yAxis: {
                    title: {
                        text: 'pH Value'
                    },
                    min: 0, // Minimum y-axis value
                    max: 14, // Maximum y-axis value
                    tickInterval: 1 // Tick interval for y-axis (1 unit)
                },
                tooltip: {
                    formatter: function () {
                        return `Time: ${Highcharts.dateFormat('%H:%M:%S', this.x)}<br><b>pH</b>: ${this.y}`;
                    }
                },
                series: [{
                    name: 'pH',
                    data: pHData,
                    color: 'green' // Choose a color for the bars
                }]
            });
        },
        error: function (error) {
            console.error('Error fetching pH data:', error);
        }
    });
}

/**
 * Função para criar um gráfico de temperatura da água com base na data especificada.
 *
 * @param {string} date - A data para a qual os dados do gráfico de temperatura da água serão obtidos.
 */
function createWaterTemperatureChart(date) {
    var parameter = 'water_temperature'; // This is the Python-style parameter name

    // Make an AJAX request to fetch water_temperature data for the specified date
    $.ajax({
        url: '/data', // Update the URL endpoint as needed
        method: 'GET',
        dataType: 'json',
        data: {
            parameter: parameter, // Use camelCase parameter name
            date: date // 'yyyy-mm-dd' format
        },
        success: function (data) {
            if (data.length === 0) {
                console.log(`No water_temperature data available for ${date}`);
                return;
            }

            // Convert Unix timestamps to "hour:min:sec" format
            data.forEach(function (point) {
                point[0] = new Date(point[0] * 1000).toLocaleTimeString('en-US', { hour12: false });
            });

            // Create a chart for water_temperature
            Highcharts.chart('waterTemperatureChart', {
                chart: {
                    type: 'line'
                },
                title: {
                    text: 'Water Temperature Data'
                },
                xAxis: {
                    title: {
                        text: 'Time'
                    },
                    labels: {
                        format: '{value}' // Display the converted timestamp
                    }
                },
                yAxis: {
                    title: {
                        text: 'Water Temperature (°C)'
                    }
                },
                series: [{
                    name: 'Water Temperature',
                    data: data,
                    color: 'blue' // Choose a color for the line
                }]
            });
        },
        error: function (error) {
            console.error('Error fetching water_temperature data:', error);
        }
    });
}

/**
 * Função para converter um texto em Python para camelCase.
 *
 * @param {string} text - O texto em Python a ser convertido.
 * @returns {string} - O texto convertido em camelCase.
 */
function pythonToCamelCase(text) {
    return text.replace(/_(.)/g, function(match, group1) {
        return group1.toUpperCase();
    });
}

/**
 * Função para criar um gráfico com base no tipo de gráfico e na data selecionada.
 *
 * @param {string} chartType - O tipo de gráfico a ser criado.
 * @param {string} selectedDate - A data selecionada para exibir no gráfico.
 */
function createChartWithDate(chartType, selectedDate) {
    console.log(`Creating ${chartType} chart for date: ${selectedDate}`);
}

/**
 * Função para verificar se uma data possui o formato válido 'yyyy-mm-dd'.
 *
 * @param {string} dateString - A string de data a ser verificada.
 * @returns {boolean} - True se a data estiver no formato válido, senão False.
 */
function isValidDateFormat(dateString) {
    const regex = /^\d{4}-\d{2}-\d{2}$/;
    return regex.test(dateString);
}

/**
 * Função para atualizar os gráficos com base na entrada do user.
 */
function updateCharts() {
    const inputDate = document.getElementById('dateInput').value;
    const errorText = document.getElementById('errorText');

    if (!isValidDateFormat(inputDate)) {
        errorText.textContent = 'Formato de data inválido: yyyy-mm-dd.';
        return;
    }

    errorText.textContent = '';

    createChart('temperature', inputDate);
    createChart('humidity', inputDate);
    createPHChart(inputDate);
    createChart('ec',inputDate);
    createWaterTemperatureChart(inputDate);
}

/**
 * Função para obter a data atual no formato 'yyyy-mm-dd'.
 *
 * @returns {string} - A data atual no formato especificado.
 */
function getCurrentDate() {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}
